import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  // Criar cordas de exemplo
  const cordas = await prisma.corda.createMany({
    data: [
      {
        name: "Crua",
        order: 1,
        styleType: "solid",
        styleValue: "#FFFFFF",
        description: "Iniciante - Primeira corda"
      },
      {
        name: "Amarela",
        order: 2,
        styleType: "solid",
        styleValue: "#F7D736",
        description: "Corda básica"
      },
      {
        name: "Laranja",
        order: 3,
        styleType: "gradient",
        styleValue: "linear-gradient(135deg, #FF6B35, #FFA500)",
        description: "Corda intermediária"
      },
      {
        name: "Azul e Verde",
        order: 4,
        styleType: "gradient",
        styleValue: "linear-gradient(135deg, #1565C0, #2E7D32)",
        description: "Corda avançada"
      }
    ],
    skipDuplicates: true
  })

  // Criar admin
  const hashedPassword = await bcrypt.hash('Admin123!', 12)
  const admin = await prisma.user.create({
    data: {
      email: 'admin@capoeira.com',
      password: hashedPassword,
      name: 'Administrador',
      isAdmin: true
    }
  })

  // Criar usuário de exemplo
  const userPassword = await bcrypt.hash('User123!', 12)
  const user = await prisma.user.create({
    data: {
      email: 'aluno@capoeira.com',
      password: userPassword,
      name: 'Aluno Exemplo',
      isAdmin: false,
      cordaId: (await prisma.corda.findFirst({ where: { order: 1 } }))?.id
    }
  })

  // Criar módulos e movimentos de exemplo
  const cordaCrua = await prisma.corda.findFirst({ where: { order: 1 } })
  
  if (cordaCrua) {
    const moduloBasico = await prisma.module.create({
      data: {
        name: "Fundamentos Básicos",
        description: "Movimentos essenciais para iniciantes",
        order: 1,
        cordaId: cordaCrua.id
      }
    })

    await prisma.movement.createMany({
      data: [
        {
          name: "Ginga",
          description: "Movimento base da capoeira",
          difficulty: "iniciante",
          videoUrl: "https://exemplo.com/videos/ginga.mp4",
          moduleId: moduloBasico.id
        },
        {
          name: "Esquiva Básica",
          description: "Primeira defesa aprendida",
          difficulty: "iniciante",
          videoUrl: "https://exemplo.com/videos/esquiva.mp4",
          moduleId: moduloBasico.id
        }
      ]
    })
  }

  console.log('Seed completed!')
  console.log('Admin credentials:')
  console.log('Email: admin@capoeira.com')
  console.log('Password: Admin123!')
  console.log('\nUser credentials:')
  console.log('Email: aluno@capoeira.com')
  console.log('Password: User123!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
3. Utilitários e Configuração