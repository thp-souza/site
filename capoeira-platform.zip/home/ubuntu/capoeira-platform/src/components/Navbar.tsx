'use client'

import { useAuth } from './AuthProvider'
import Link from 'next/link'
import { useState } from 'react'

export function Navbar() {
  const { user, logout } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="fixed w-full bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-capoeira-yellow to-capoeira-green rounded-full" />
              <span className="text-xl font-bold text-gray-900">Capoeira Platform</span>
            </Link>
          </div>

          <div className="hidden sm:flex sm:items-center sm:space-x-4">
            {user ? (
              <>
                <span className="text-gray-700">
                  Olá, {user.name} {user.isAdmin && '(Admin)'}
                </span>
                <Link
                  href={user.isAdmin ? '/admin' : '/dashboard'}
                  className="text-gray-700 hover:text-capoeira-green px-3 py-2 rounded-md text-sm font-medium"
                >
                  Painel
                </Link>
                <button
                  onClick={logout}
                  className="bg-capoeira-red text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-red-700"
                >
                  Sair
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="bg-capoeira-green text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-700"
              >
                Entrar
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="sm:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="sm:hidden bg-white border-t">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {user ? (
              <>
                <div className="px-3 py-2 text-gray-700">
                  Olá, {user.name} {user.isAdmin && '(Admin)'}
                </div>
                <Link
                  href={user.isAdmin ? '/admin' : '/dashboard'}
                  className="block px-3 py-2 text-gray-700 hover:text-capoeira-green"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Painel
                </Link>
                <button
                  onClick={() => {
                    logout()
                    setIsMenuOpen(false)
                  }}
                  className="block w-full text-left px-3 py-2 text-gray-700 hover:text-capoeira-red"
                >
                  Sair
                </button>
              </>
            ) : (
              <Link
                href="/login"
                className="block px-3 py-2 text-gray-700 hover:text-capoeira-green"
                onClick={() => setIsMenuOpen(false)}
              >
                Entrar
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}
6. Páginas Principais
src/app/page.tsx (Home)

tsx
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Plataforma <span className="gradient-text">Privada</span> de Capoeira
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
            Sistema exclusivo para alunos autorizados. Acesse sua corda, aprenda movimentos
            e evolua na arte da capoeira.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/login"
              className="inline-flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-white bg-capoeira-green hover:bg-green-700 md:py-4 md:text-lg md:px-10"
            >
              Acessar Plataforma
            </Link>
            <Link
              href="#features"
              className="inline-flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-capoeira-green bg-white border border-capoeira-green hover:bg-gray-50 md:py-4 md:text-lg md:px-10"
            >
              Saiba Mais
            </Link>
          </div>
        </div>

        <div id="features" className="mt-32">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Recursos da Plataforma
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-yellow to-orange-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Cordas Personalizadas</h3>
              <p className="text-gray-600">
                Sistema de graduação totalmente personalizável pelo administrador.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-green to-blue-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Conteúdo Exclusivo</h3>
              <p className="text-gray-600">
                Vídeos e materiais acessíveis apenas para sua corda atual.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-blue to-purple-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Aprendizado Progressivo</h3>
              <p className="text-gray-600">
                Módulos organizados por dificuldade para evolução constante.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}