import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import { cookies } from 'next/headers'
import { prisma } from './prisma'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

export interface UserPayload {
  id: string
  email: string
  name: string
  isAdmin: boolean
  cordaId?: string
}

export async function authenticateUser(email: string, password: string): Promise<UserPayload | null> {
  const user = await prisma.user.findUnique({
    where: { email },
    include: { corda: true }
  })

  if (!user) return null

  const isValid = await bcrypt.compare(password, user.password)
  if (!isValid) return null

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    isAdmin: user.isAdmin,
    cordaId: user.cordaId || undefined
  }
}

export function createToken(payload: UserPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' })
}

export function verifyToken(token: string): UserPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as UserPayload
  } catch {
    return null
  }
}

export async function getCurrentUser() {
  const cookieStore = cookies()
  const token = cookieStore.get('auth-token')?.value

  if (!token) return null

  return verifyToken(token)
}

export async function requireAuth(requireAdmin = false) {
  const user = await getCurrentUser()
  
  if (!user) {
    throw new Error('Não autenticado')
  }

  if (requireAdmin && !user.isAdmin) {
    throw new Error('Acesso não autorizado')
  }

  return user
}
4. Layout Principal