import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { verifyToken } from '@/lib/auth'

const protectedRoutes = ['/dashboard', '/admin']
const adminRoutes = ['/admin']

export function middleware(request: NextRequest) {
  const token = request.cookies.get('auth-token')?.value
  const { pathname } = request.nextUrl

  // Verificar se a rota é protegida
  const isProtectedRoute = protectedRoutes.some(route => 
    pathname.startsWith(route)
  )
  
  const isAdminRoute = adminRoutes.some(route => 
    pathname.startsWith(route)
  )

  if (!isProtectedRoute) {
    return NextResponse.next()
  }

  // Verificar autenticação
  if (!token) {
    const loginUrl = new URL('/login', request.url)
    loginUrl.searchParams.set('from', pathname)
    return NextResponse.redirect(loginUrl)
  }

  try {
    const user = verifyToken(token)
    
    if (!user) {
      const loginUrl = new URL('/login', request.url)
      return NextResponse.redirect(loginUrl)
    }

    // Verificar acesso admin
    if (isAdminRoute && !user.isAdmin) {
      return NextResponse.redirect(new URL('/dashboard', request.url))
    }

    // Adicionar headers de usuário para páginas server-side
    const headers = new Headers(request.headers)
    headers.set('x-user-id', user.id)
    headers.set('x-user-email', user.email)
    headers.set('x-user-is-admin', String(user.isAdmin))

    return NextResponse.next({ headers })
  } catch (error) {
    console.error('Middleware auth error:', error)
    const loginUrl = new URL('/login', request.url)
    return NextResponse.redirect(loginUrl)
  }
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
}
11. README para Instalação