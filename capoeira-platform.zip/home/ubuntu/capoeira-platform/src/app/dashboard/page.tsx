import { requireAuth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'

export default async function DashboardPage() {
  const user = await requireAuth()
  
  if (user.isAdmin) {
    // Redirecionar admin para painel admin
    // (em produção, usar redirect do Next.js)
  }

  const corda = user.cordaId ? await prisma.corda.findUnique({
    where: { id: user.cordaId }
  }) : null

  const modules = user.cordaId ? await prisma.module.findMany({
    where: { cordaId: user.cordaId },
    orderBy: { order: 'asc' },
    include: {
      movements: {
        orderBy: { createdAt: 'asc' }
      }
    }
  }) : []

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Meu Progresso</h1>
        <p className="text-gray-600 mt-2">
          Bem-vindo ao seu dashboard de aprendizado
        </p>
      </div>

      {corda && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Sua Corda</h2>
          </div>
          <div 
            className="p-6 rounded-xl shadow-lg text-white"
            style={{
              background: corda.styleType === 'solid' 
                ? corda.styleValue 
                : corda.styleType === 'gradient'
                ? corda.styleValue
                : `url(${corda.styleValue}) center/cover`
            }}
          >
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-bold">{corda.name}</h3>
                <p className="mt-2 opacity-90">{corda.description}</p>
              </div>
              <div className="text-4xl font-bold opacity-80">
                {corda.order}
              </div>
            </div>
          </div>
        </div>
      )}

      {modules.length > 0 ? (
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Módulos da sua Corda</h2>
          <div className="space-y-6">
            {modules.map((module) => (
              <div key={module.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{module.name}</h3>
                      <p className="text-gray-600 mt-1">{module.description}</p>
                    </div>
                    <span className="px-3 py-1 text-sm bg-capoeira-yellow text-gray-900 rounded-full">
                      Módulo {module.order}
                    </span>
                  </div>
                  
                  {module.movements.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-gray-900 mb-3">Movimentos deste módulo:</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        {module.movements.map((movement) => (
                          <div key={movement.id} className="border border-gray-200 rounded-lg p-4 hover:border-capoeira-green transition-colors">
                            <div className="flex justify-between items-start">
                              <div>
                                <h5 className="font-medium text-gray-900">{movement.name}</h5>
                                <p className="text-sm text-gray-600 mt-1">{movement.description}</p>
                              </div>
                              <span className={`px-2 py-1 text-xs rounded-full ${
                                movement.difficulty === 'iniciante' 
                                  ? 'bg-green-100 text-green-800'
                                  : movement.difficulty === 'intermediario'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {movement.difficulty}
                              </span>
                            </div>
                            <div className="mt-3">
                              <div className="aspect-video bg-gray-900 rounded overflow-hidden">
                                <video
                                  src={movement.videoUrl}
                                  controls
                                  className="w-full h-full"
                                  title={`Vídeo: ${movement.name}`}
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <svg className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum módulo disponível</h3>
          <p className="text-gray-600">
            Aguarde o administrador adicionar conteúdo à sua corda.
          </p>
        </div>
      )}

      {!corda && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800">
            Você ainda não foi atribuído a uma corda. Entre em contato com o administrador.
          </p>
        </div>
      )}
    </div>
  )
}
9. Painel Admin