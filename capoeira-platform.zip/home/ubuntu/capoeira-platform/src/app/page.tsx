import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Plataforma <span className="gradient-text">Privada</span> de Capoeira
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
            Sistema exclusivo para alunos autorizados. Acesse sua corda, aprenda movimentos
            e evolua na arte da capoeira.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/login"
              className="inline-flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-white bg-capoeira-green hover:bg-green-700 md:py-4 md:text-lg md:px-10"
            >
              Acessar Plataforma
            </Link>
            <Link
              href="#features"
              className="inline-flex items-center justify-center px-8 py-3 text-base font-medium rounded-md text-capoeira-green bg-white border border-capoeira-green hover:bg-gray-50 md:py-4 md:text-lg md:px-10"
            >
              Saiba Mais
            </Link>
          </div>
        </div>

        <div id="features" className="mt-32">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Recursos da Plataforma
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-yellow to-orange-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Cordas Personalizadas</h3>
              <p className="text-gray-600">
                Sistema de graduação totalmente personalizável pelo administrador.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-green to-blue-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Conteúdo Exclusivo</h3>
              <p className="text-gray-600">
                Vídeos e materiais acessíveis apenas para sua corda atual.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-gradient-to-r from-capoeira-blue to-purple-500 rounded-lg mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Aprendizado Progressivo</h3>
              <p className="text-gray-600">
                Módulos organizados por dificuldade para evolução constante.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
